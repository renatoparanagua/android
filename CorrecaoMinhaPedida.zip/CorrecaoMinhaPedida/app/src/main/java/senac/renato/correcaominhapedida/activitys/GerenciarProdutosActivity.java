package senac.renato.correcaominhapedida.activitys;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;



import senac.renato.correcaominhapedida.R;

public class GerenciarProdutosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerenciar_produtos);
    }
}
