package com.example.aluno.myapplication.util;

/**
 * Created by Aluno on 04/09/2017.
 */

public class Constantes {
    public static final int REQUEST_AV1 = 100;
    public static final int REQUEST_AV2 = 101;
    public static final int RESULT_VOLTAR_EDITAR = 102;
    public static final int RESULT_VOLTAR_LIMPAR = 103;
    public static final int REQUEST_RESULTADO = 104;
}
